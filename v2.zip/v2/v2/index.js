const { Storage } = require('@google-cloud/storage');
const fs = require('fs').promises;
const path = require('path');
const os = require('os');
const mime = require('mime-types');

const sourceBucket = 'uploads-gj';
const destinationBucket = 'final-images-gj';
const allowedImageTypes = ['image/png', 'image/jpeg'];
const tmpDir = path.join(os.tmpdir(), 'cloud-function-downloads');

async function downloadObject(bucketName, objectName) {
  const storage = new Storage();
  const tmpFilePath = path.join(tmpDir, objectName);

  await fs.mkdir(tmpDir, { recursive: true });

  try {
    const [data] = await storage.bucket(bucketName).file(objectName).download();
    await fs.writeFile(tmpFilePath, data);
    console.log(`Object downloaded to: ${tmpFilePath}`);
  } catch (error) {
    console.error(`Error downloading object: ${error}`);
    throw error;
  }

  return tmpFilePath;
}

exports.generateThumbData = async (event, context) => {
  const bucketName = event.bucket;
  const objectName = event.name;

  try {
    const filePath = await downloadObject(bucketName, objectName);
    console.log("Successfully downloaded the object:", objectName);

    const fileContentType = mime.lookup(filePath);

    if (allowedImageTypes.includes(fileContentType)) {
      try {
        const storage = new Storage();

        // Get metadata to obtain the generation number
        const [metadata] = await storage.bucket(sourceBucket).file(objectName).getMetadata();
        const generationNumber = metadata.generation;

        // Generate the filename by combining the generation number and file type
        const uniqueFilename = `${generationNumber}.${mime.extension(fileContentType)}`;

        // Copy the uploaded file to final-images-gj with the new unique filename
        await storage.bucket(sourceBucket).file(objectName).copy(storage.bucket(destinationBucket).file(uniqueFilename));
        console.log(`Image copied to ${destinationBucket} bucket with new filename: ${uniqueFilename}`);

        // Delete the original file from uploads-gj
        await storage.bucket(sourceBucket).file(objectName).delete();
        console.log(`Original file deleted from ${sourceBucket} bucket: ${objectName}`);
      } catch (error) {
        console.error(`Error copying and deleting files: ${error}`);
      }
    } else {
      try {
        const storage = new Storage();
        // Delete non-image file from uploads-gj
        await storage.bucket(sourceBucket).file(objectName).delete();
        console.log(`Non-image file deleted from ${sourceBucket} bucket: ${objectName}`);
      } catch (error) {
        console.error(`Error deleting non-image file: ${error}`);
      }
    }
  } catch (error) {
    console.error("Error processing object:", error);
  }

  try {
    console.log("Simulating deletion of temporary directory:", tmpDir);
    await fs.rm(tmpDir, { recursive: true, force: true });
  } catch (error) {
    console.error("Error simulating deletion of temporary directory:", error);
  }
};
