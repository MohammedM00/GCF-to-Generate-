const { Storage } = require('@google-cloud/storage');
const { Firestore } = require('@google-cloud/firestore');
const fse = require('fs-extra');
const path = require('path');
const os = require('os');
const mime = require('mime-types');
const getExif = require('exif-async');
const parseDMS = require('parse-dms');
const sharp = require('sharp');

const sourceBucket = 'uploads-gj';
const thumbnailBucket = 'thumbnail-images-gj';
const destinationBucket = 'final-images-gj';
const allowedImageTypes = ['image/png', 'image/jpeg'];
const tmpDir = path.join(os.tmpdir(), 'cloud-function-downloads');

const fs = fse.promises;

const firestore = new Firestore({projectId: "global-jags-assignment"});

async function downloadObject(bucketName, objectName) {
  const storage = new Storage();
  const tmpFilePath = path.join(tmpDir, objectName);

  await fs.mkdir(tmpDir, { recursive: true });

  try {
    const [data] = await storage.bucket(bucketName).file(objectName).download();
    await fs.writeFile(tmpFilePath, data);
    console.log(`Object downloaded to: ${tmpFilePath}`);
  } catch (error) {
    console.error(`Error downloading object: ${error}`);
    throw error;
  }

  return tmpFilePath;
}

async function readExifData(localFile) {
  let exifData;
  try {
    exifData = await getExif(localFile);
    return exifData.gps;
  } catch(err) {
    console.log(err);
    return null;
  }
}

function getGPSCoordinates(g) {
  const latString = `${g.GPSLatitude[0]}:${g.GPSLatitude[1]}:${g.GPSLatitude[2]}${g.GPSLatitudeRef}`;
  const lonString = `${g.GPSLongitude[0]}:${g.GPSLongitude[1]}:${g.GPSLongitude[2]}${g.GPSLongitudeRef}`;
  const degCoords = parseDMS(`${latString} ${lonString}`);
  return degCoords;
}

async function generateThumbnail(sourcePath, targetPath) {
  await sharp(sourcePath)
    .resize({ width: 100, height: 100 })
    .toFile(targetPath);
}

async function writeToFirestore(uniqueFilename, gpsDecimal) {

    const collectionRef = firestore.collection('photos');
    const documentData = {
      thumbURL: `https://storage.googleapis.com/${thumbnailBucket}/${uniqueFilename}`, // Replace 'gs' with 'https' if you want a public URL
      imageURL: `https://storage.googleapis.com/${destinationBucket}/${uniqueFilename}`, // Replace 'gs' with 'https' if you want a public URL
      latitude: gpsDecimal.lat,
      longitude: gpsDecimal.lon,
    };

    await collectionRef.add(documentData);
    console.log(`Document created: ${documentData}`);
}

exports.generateThumbData = async (event, context) => {
  const bucketName = event.bucket;
  const objectName = event.name;

  try {
    const filePath = await downloadObject(bucketName, objectName);
    console.log("Successfully downloaded the object:", objectName);

    const fileContentType = mime.lookup(filePath);

    if (allowedImageTypes.includes(fileContentType)) {
      try {

        const gpsData = await readExifData(filePath);
        
        let gpsDecimal;
        
        if (gpsData) {
          gpsDecimal = getGPSCoordinates(gpsData);

          console.log("GPS Coordinates in Decimal Format:");
          console.log("Latitude:", gpsDecimal.lat);
          console.log("Longitude:", gpsDecimal.lon);
        }


        const storage = new Storage();

        // Get metadata to obtain the generation number
        const [metadata] = await storage.bucket(sourceBucket).file(objectName).getMetadata();
        const generationNumber = metadata.generation;

        // Generate the filename by combining the generation number and file type
        const uniqueFilename = `${generationNumber}.${mime.extension(fileContentType)}`;

        // Copy the uploaded file to final-images-gj with the new unique filename
        await storage.bucket(sourceBucket).file(objectName).copy(storage.bucket(destinationBucket).file(uniqueFilename));
        console.log(`Image copied to ${destinationBucket} bucket with new filename: ${uniqueFilename}`);

        // Delete the original file from uploads-gj
        await storage.bucket(sourceBucket).file(objectName).delete();
        console.log(`Original file deleted from ${sourceBucket} bucket: ${objectName}`);

        // Generate a thumbnail and save it to thumbnail-images-gj
        const thumbnailPath = path.join(tmpDir, uniqueFilename);
        await generateThumbnail(filePath, thumbnailPath);

        await storage.bucket(thumbnailBucket).upload(thumbnailPath, {
          destination: uniqueFilename,
        });
        console.log(`Thumbnail saved to ${thumbnailBucket} bucket with filename: ${uniqueFilename}`);

        // Delete the temporary thumbnail file
        await fs.unlink(thumbnailPath);
        console.log("Temporary thumbnail file deleted.");

        //saving photo object to Firestore
        writeToFirestore(uniqueFilename, gpsDecimal);

      } catch (error) {
        console.error(`Error copying and deleting files: ${error}`);
      }
    } else {
      try {
        const storage = new Storage();
        // Delete non-image file from uploads-gj
        await storage.bucket(sourceBucket).file(objectName).delete();
        console.log(`Non-image file deleted from ${sourceBucket} bucket: ${objectName}`);
      } catch (error) {
        console.error(`Error deleting non-image file: ${error}`);
      }
    }
  } catch (error) {
    console.error("Error processing object:", error);
  }

  try {
    console.log("Simulating deletion of temporary directory:", tmpDir);
    await fs.rm(tmpDir, { recursive: true, force: true });
  } catch (error) {
    console.error("Error simulating deletion of temporary directory:", error);
  }
};
