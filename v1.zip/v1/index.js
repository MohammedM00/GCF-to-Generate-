const { Storage } = require('@google-cloud/storage');
const fs = require('fs-extra');
const path = require('path');
const os = require('os');

const tmpDir = path.join(os.tmpdir(), 'cloud-function-downloads');

async function downloadObject(bucketName, objectName) {
  const storage = new Storage();

  // Create temporary file path
  const tmpFilePath = path.join(tmpDir, objectName);

  // Ensure temporary directory exists
  await fs.promises.mkdir(tmpDir, { recursive: true });

  // Download the object and write to file
  try {
    const [data] = await storage.bucket(bucketName).file(objectName).download();
    await fs.promises.writeFile(tmpFilePath, data);
    console.log(`Object downloaded to: ${tmpFilePath}`);
  } catch (error) {
    console.error(`Error downloading object: ${error}`);
    throw error; // Re-throw the error for further handling
  }

  return tmpFilePath;
}

exports.generateThumbData = async (event, context) => {
  // Extract bucket and object names from event data
  const bucketName = event.bucket;
  const objectName = event.name;

  try {
    const filePath = await downloadObject(bucketName, objectName);
    console.log("Succesfully downloaded the object:", objectName)
    // Process the downloaded file using filePath (e.g., call another function)

    console.log("Simulating deletion of temporary directory:", tmpDir);
    await fs.promises.rm(tmpDir, { recursive: true });
    
  } catch (error) {
    console.error("Error downloading object:", error);
    // Handle download error (e.g., retry or send notification)
  }
};